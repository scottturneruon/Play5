import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bug extends Actor
{
    /**
     * Act - do whatever the bug wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
          if (lobster_detector()==true)
         {
             setRotation(-45);
             
             move(1);
          }
    } 
     private boolean lobster_detector()
    {
        Actor bug;
        boolean the_truth;
        bug=getOneObjectAtOffset(0,0,lobster.class);
        if (bug!=null)
        {
            the_truth=true;
        }
        else
        {
            the_truth=false;
        }
        return the_truth;
    }
}
