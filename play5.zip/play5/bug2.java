import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bug2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bug2 extends Actor
{
    /**
     * Act - do whatever the bug2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private static int lobsterX=0;
    private static int lobsterY=0;
    
    public void act() 
    {
          if (lobster_detector()==true)
         {
             setLocation(lobsterX+1, lobsterY);
            }
    } 
     private boolean lobster_detector()
    {
        Actor bug;
        boolean the_truth;
        bug=getOneObjectAtOffset(0,0,lobster.class);
        if (bug!=null)
        {
            the_truth=true;
            lobsterX=bug.getX();
            lobsterY=bug.getY();
        }
        else
        {
            the_truth=false;
        }
        return the_truth;
    }  
}
