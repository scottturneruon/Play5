import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class lobster here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class lobster extends Actor
{
    /**
     * Act - do whatever the lobster wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
           forward(1);//100 steps forward;
          
    } 

    private void turnRight(int degrees)
    {
        turn(degrees);
        Greenfoot.delay(1);
    }
    private void turnLeft(int degrees)
    {
        turn(-1*degrees);
        Greenfoot.delay(1);
    }
    private void forward(int step)
    {
        for (int loop=0;loop<step;loop=loop+1)
        {
         move(1);
        }
    }
    private void backward(int step)
    {
        turn(180);
        move(step);
        Greenfoot.delay(1);
    }
    private void stop()
    {
       Greenfoot.stop();
    }
    private boolean bug_detector()
    {
        Actor bug;
        boolean the_truth;
        bug=getOneObjectAtOffset(0,0,bug.class);
        if (bug!=null)
        {
            the_truth=true;
        }
        else
        {
            the_truth=false;
        }
        return the_truth;
    }

    
}
